import express from "express";
import cors from "cors";
import dotenv from "dotenv";
dotenv.config();

const app = express();
app.use(cors()); // For production, restrict this to your app's hosted domain.
app.use(express.json({limit:"32kb"}));

const API_KEY = process.env.GEMINI_API_KEY;
const MODEL = process.env.GEMINI_MODEL || "gemini-2.5-flash";

app.get("/", (_req,res)=>res.send("Maya AI backend is running."));

app.post("/api/chat", async (req,res) => {
  try {
    if (!API_KEY) return res.status(500).json({error:"Backend owner has not configured the AI key."});
    const message = String(req.body?.message || "").trim();
    if (!message) return res.status(400).json({error:"Message is empty."});
    if (message.length > 4000) return res.status(400).json({error:"Message is too long."});

    const previous = Array.isArray(req.body?.history) ? req.body.history.slice(-12) : [];
    const contents = previous
      .filter(x => (x.role === "user" || x.role === "model") && typeof x.text === "string")
      .map(x => ({role:x.role, parts:[{text:x.text.slice(0,4000)}]}));
    contents.push({role:"user", parts:[{text:message}]});

    const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent`, {
      method:"POST",
      headers:{"Content-Type":"application/json","x-goog-api-key":API_KEY},
      body:JSON.stringify({
        systemInstruction:{parts:[{text:"You are Maya, a helpful, friendly AI assistant. Reply in the same language as the user, especially Bengali when they write Bengali. Be accurate, age-appropriate, and clear. If unsure, say so."}]},
        contents,
        generationConfig:{temperature:0.7,maxOutputTokens:900}
      })
    });
    const data = await response.json();
    if (!response.ok) {
      console.error("Gemini API error:", data?.error?.message || response.status);
      return res.status(502).json({error:"AI service did not respond. Check the backend key, model name, or quota."});
    }
    const reply = data?.candidates?.[0]?.content?.parts?.map(p=>p.text || "").join("").trim();
    if (!reply) return res.status(502).json({error:"AI returned an empty response."});
    res.json({reply});
  } catch (error) {
    console.error(error);
    res.status(500).json({error:"Unexpected backend error."});
  }
});

const port = Number(process.env.PORT || 3000);
app.listen(port, ()=>console.log(`Maya backend listening on ${port}`));
