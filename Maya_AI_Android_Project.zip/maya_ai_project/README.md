# Maya AI — Android starter project

This is a working **starter project**, not a precompiled APK. It includes:
- Maya-style dark blue/neon chat screen
- Bengali/English text chat through the Gemini API
- Microphone speech-to-text where the Android WebView/browser supports it
- Spoken answers using device text-to-speech
- A small Node.js backend so the Gemini API key is **not stored inside the APK**

## Important
The Android app cannot contact Gemini until you deploy the backend and configure a private API key. API usage may have limits or costs. Do not share your API key or put it in `www/app.js`. Ask a parent/guardian to help with account setup and any payment or billing choices.

## 1. Set up the private backend
1. Install Node.js on a computer.
2. Open a terminal in the `server` folder.
3. Run `npm install`.
4. Copy `.env.example` to `.env`.
5. Put your Gemini API key in `.env` as `GEMINI_API_KEY=...`. Keep `.env private; never upload it publicly.
6. Run `npm start`.
7. Deploy this `server` folder to a trusted Node.js hosting service that supports environment variables and HTTPS. Set `GEMINI_API_KEY` and optionally `GEMINI_MODEL` in that host's private environment settings.
8. Test the deployed address by opening it in a browser; it should say `Maya AI backend is running.`

Gemini API reference: https://ai.google.dev/api/generate-content

## 2. Connect the app to your backend
Open `www/app.js` and replace:
`https://YOUR-BACKEND-URL.example.com`
with your deployed HTTPS backend address (no trailing slash).

## 3. Build the Android app
On a computer with Android Studio and Node.js:
1. Open a terminal in this project folder.
2. Run `npm install`.
3. Run `npx cap add android` (only the first time).
4. Run `npx cap sync android`.
5. Run `npx cap open android`.
6. In Android Studio, wait for Gradle sync. Connect your Android phone with USB debugging enabled, or use the Build menu to create an APK.
7. For a new APK after editing the web app, run `npx cap sync android` again before building.

## Voice notes
Voice input uses the speech recognition support available in the Android WebView. Support can vary by device and installed speech services. The microphone permission prompt may appear. Voice output uses the device's built-in speech synthesis.

## Privacy and safety
- Chat messages are sent to your configured backend and then to Google's Gemini API to generate replies.
- The sample backend keeps no chat database; conversation history is held temporarily in the app session.
- Before sharing the app with others, restrict backend CORS, add authentication/rate limits, and publish a privacy notice.
- Do not put passwords, personal addresses, or other private information into chat.
