const API_BASE = "https://YOUR-BACKEND-URL.example.com"; // Replace after deploying your private backend.
const chat = document.getElementById("chat");
const promptBox = document.getElementById("prompt");
const sendButton = document.getElementById("send");
const micButton = document.getElementById("mic");
const statusText = document.getElementById("status");
let history = [];
let busy = false;

function addMessage(text, who) {
  const row = document.createElement("div");
  row.className = `message ${who}`;
  if (who === "maya") {
    const avatar = document.createElement("div");
    avatar.className = "avatar";
    avatar.textContent = "M";
    row.appendChild(avatar);
  }
  const bubble = document.createElement("div");
  bubble.className = "bubble";
  bubble.textContent = text;
  row.appendChild(bubble);
  chat.appendChild(row);
  row.scrollIntoView({behavior:"smooth", block:"end"});
  return bubble;
}

async function sendMessage(text) {
  const clean = text.trim();
  if (!clean || busy) return;
  if (API_BASE.includes("YOUR-BACKEND-URL")) {
    addMessage("অ্যাপটি প্রায় প্রস্তুত! AI চালু করতে প্রথমে ব্যক্তিগত backend deploy করে app.js-এর API_BASE-এ তার URL বসাতে হবে। README-তে ধাপ দেওয়া আছে।", "maya");
    return;
  }
  addMessage(clean, "user");
  promptBox.value = "";
  busy = true; sendButton.disabled = true; statusText.textContent = "Maya ভাবছে...";
  const replyBubble = addMessage("একটু অপেক্ষা করো…", "maya");
  try {
    const res = await fetch(`${API_BASE}/api/chat`, {
      method:"POST", headers:{"Content-Type":"application/json"},
      body:JSON.stringify({message:clean, history})
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || "সার্ভারে সমস্যা হয়েছে");
    replyBubble.textContent = data.reply;
    history.push({role:"user", text:clean},{role:"model", text:data.reply});
    history = history.slice(-16);
    speakIfEnabled(data.reply);
    statusText.textContent = "Maya প্রস্তুত";
  } catch (err) {
    replyBubble.textContent = `দুঃখিত, সংযোগে সমস্যা হয়েছে: ${err.message}`;
    statusText.textContent = "সংযোগ পরীক্ষা করো";
  } finally { busy = false; sendButton.disabled = false; promptBox.focus(); }
}
sendButton.addEventListener("click",()=>sendMessage(promptBox.value));
promptBox.addEventListener("keydown",e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();sendMessage(promptBox.value)}});
document.querySelectorAll(".suggestion").forEach(b=>b.addEventListener("click",()=>sendMessage(b.dataset.prompt)));

let voiceEnabled = true;
function speakIfEnabled(text) {
  if (!voiceEnabled || !("speechSynthesis" in window)) return;
  window.speechSynthesis.cancel();
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = /[\u0980-\u09FF]/.test(text) ? "bn-IN" : "en-US";
  utterance.rate = 1;
  window.speechSynthesis.speak(utterance);
}

const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
if (SpeechRecognition) {
  const recognition = new SpeechRecognition();
  recognition.lang = "bn-IN";
  recognition.interimResults = false;
  recognition.onstart = ()=>statusText.textContent = "শুনছি…";
  recognition.onresult = e=>{promptBox.value = e.results[0][0].transcript; statusText.textContent="কথা পাওয়া গেছে";};
  recognition.onerror = ()=>statusText.textContent="মাইক্রোফোন কাজ করছে না";
  recognition.onend = ()=>{if(statusText.textContent==="শুনছি…")statusText.textContent="Maya প্রস্তুত"};
  micButton.addEventListener("click",()=>{try{recognition.start()}catch(e){}});
} else {
  micButton.disabled = true;
  micButton.title = "এই ব্রাউজারে voice input সমর্থিত নয়";
}
